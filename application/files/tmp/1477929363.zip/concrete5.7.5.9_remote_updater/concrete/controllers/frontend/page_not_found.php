<?php
namespace Concrete\Controller\Frontend;
use Controller;
class PageNotFound extends Controller {
	
	
	protected $viewPath = '/frontend/page_not_found';

	
}