<?php

return array(
    'installed' => false,

    'cache' => array(
        'enabled' => false
    )
);
